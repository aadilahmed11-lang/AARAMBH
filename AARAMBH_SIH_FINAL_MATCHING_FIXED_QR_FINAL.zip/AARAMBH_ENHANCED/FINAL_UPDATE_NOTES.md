# AARAMBH Final Update

## Fixed
- Voice helper is collapsed to a small floating microphone so it no longer blocks the application view.
- Every one-question applicant profile page now has a visible **Speak your answer** button.
- Voice answers are inserted into the active question and the next question is read aloud.
- District, state, city/local area, age and disability percentage support typed or spoken entry.
- Voice help supports English, Hindi and Tamil browser speech recognition/TTS where the browser provides it.
- Scheme matching now runs automatically when the AI Scheme Match step opens.
- Matching uses applicant details: category, income, disability status, age, state, purpose/profile keywords, requested amount and configured eligibility rules.
- Match cards show score, matching factors and gaps instead of only a raw number.
- Applicant profile questions expanded to cover age, gender, social category, disability status/type/percentage, marital status, urban/rural residence, minority status, employment status, location and document-readiness fields.
- Social-category choices include SC, ST, BC, OBC, BCM, EWS, General/Other and Prefer not to say.
- Added additional government-scheme discovery records sourced from the official myScheme catalogue, including PM-DAKSH, PMEGP, PM SVANidhi and Khelo India inclusiveness support.
- State-specific schemes are represented as discovery records; the UI links to the official source for verification.
- Existing SQLite databases are upgraded automatically with new profile and scheme-targeting columns.
- `uvicorn[standard]` is explicitly included in backend requirements for fresh virtual environments.

## Important data note
The added myScheme records are discovery data for the prototype. Eligibility, rates, limits, state availability and application instructions must be verified on the linked official government page before a production deployment.
