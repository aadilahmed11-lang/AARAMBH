# AARAMBH SIH Final Enhancement Changelog

## Added / strengthened

- Unified end-to-end Business and Education guided journeys.
- Explainable recommendation cards with explicit rule-first messaging.
- Neutral scheme comparison for up to three schemes.
- Financial planning with EMI, total repayment, total interest and moratorium.
- Application-specific document checklist and readiness support.
- 50 km partner routing with scheme-aware filtering and partner details.
- Directions link and selected-partner workflow.
- Application timeline and readiness score UI.
- Offline-first PWA shell with service worker and IndexedDB cache/queue.
- Offline scheme recommendation from cached catalogue data.
- Offline application queue and server synchronization endpoint.
- Cached partner distance calculation within 50 km.
- English, Hindi and Tamil UI foundation.
- Government/Admin data-governance fields and verification actions.
- Scheme/partner source and review-date visibility.
- Fixed scheme comparison service so it uses the actual SchemeDocument/Scheme fields.
- Fixed notification service field mismatch with the current Notification model.
- Restricted public registration to applicant accounts; partner/admin access remains provisioned by the organization.
- Added clearer prototype/production boundaries for Aadhaar, rates, partner data and routing risk gates.

## Validation

- Backend Python modules compiled successfully with `py_compile`.
- Final ZIP should be built from the current project root.
- Frontend build should be run locally after `npm.cmd install` because package installation was not available in the packaging environment.


## UI stability repair
- Fixed dashboard crash when an invalid `aarambh_lang` value exists in localStorage by falling back to English.
- Added missing `LayoutDashboard` icon import used by the Government/Admin navigation.
- Added language validation and a React recovery boundary so unexpected UI errors no longer leave a completely blank screen.
- Frontend JSX/JavaScript syntax checked with TypeScript compiler (`tsc`, no emit).
- Backend Python sources checked with `python -m compileall`.
