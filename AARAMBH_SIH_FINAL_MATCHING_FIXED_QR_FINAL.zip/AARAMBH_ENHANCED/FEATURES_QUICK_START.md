# AARAMBH Features - Quick Start Guide

## 🚀 Getting Started

### 1. Install Dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 2. Start the API Server
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 3. Access Feature Endpoints
Base URL: `http://localhost:8000/api/v1/features`

---

## 📋 Quick Feature Overview

### Applicant Features (User-Facing)

#### ✅ Check Eligibility
```
GET /eligibility-explanation/{user_id}/{scheme_id}
```
Get personalized eligibility explanation for a scheme.

#### 🎯 View Match Score
```
POST /match-cards/{user_id}
Body: {"scheme_ids": [1, 2, 3]}
```
See why you match specific schemes.

#### 📊 Track Application Progress
```
GET /application-readiness/{user_id}/{application_id}
GET /document-readiness/{user_id}/{application_id}
```
Monitor your readiness and document status.

#### 🏦 Find Best Partners
```
GET /partner-matching/{user_id}/{scheme_id}?location=Maharashtra
```
Get ranked bank partners sorted by suitability.

#### 💰 Calculate EMI
```
POST /emi-calculator
Body: {
  "loan_amount": 500000,
  "scheme_id": 1,
  "tenure_months": 60
}
```
See monthly payments and repayment schedule.

#### 📈 Compare Schemes
```
POST /scheme-comparison
Body: {"scheme_ids": [1, 2, 3]}
```
Side-by-side comparison of schemes.

#### 🔔 Check Notifications
```
GET /notifications/{user_id}
GET /notifications/{user_id}?unread_only=true
POST /notifications/{notification_id}/read
```
Manage application alerts.

#### 🔍 Application Timeline
```
GET /application-timeline/{application_id}
```
Visual progress tracker with timestamps.

#### 📄 Missing Documents
```
GET /missing-information/{user_id}/{application_id}
```
Know exactly what's needed to proceed.

#### 📱 Offline Access
```
GET /offline-data/{user_id}
GET /sync-status/{user_id}
```
Access data when connectivity is poor.

---

### Bank/Partner Features

#### 📋 Review Applications
```
GET /partner-report/{application_id}
```
Get comprehensive applicant profile for underwriting.

---

### Government Admin Features

#### 🗺️ Geographic Demand
```
GET /admin/geographic-analytics
```
See demand distribution by state.

#### 📊 Scheme Performance
```
GET /admin/scheme-performance
```
Monitor scheme-level metrics.

#### 📈 Dashboard
```
GET /admin/dashboard
```
Unified analytics dashboard.

---

### Demo & Testing Features

#### 🧪 Demo Scenarios
```
GET /demo/scenarios
POST /demo/create/{scenario_id}?role=applicant
```
Pre-configured demo applications for testing.

Available scenarios:
1. Dairy Farmer
2. Retail Shop Owner
3. Manufacturing Unit
4. Agricultural Business
5. Women Entrepreneur

---

## 📊 Sample API Responses

### Eligibility Explanation
```json
{
  "scheme_name": "PM MUDRA Yojana",
  "is_eligible": true,
  "simple_explanation": "Great news! You're eligible for this scheme.",
  "eligible_reasons": [
    "✓ Business type matches",
    "✓ Loan amount is in range"
  ],
  "next_steps": [
    "Review scheme details",
    "Gather documents",
    "Submit application"
  ]
}
```

### EMI Calculator
```json
{
  "loan_amount": 500000,
  "annual_interest_rate": 8.5,
  "tenure_months": 60,
  "monthly_emi": 10106.08,
  "total_repayment": 606364.80,
  "total_interest": 106364.80,
  "repayment_schedule": [
    {
      "month": 1,
      "emi": 10106.08,
      "principal": 6940.39,
      "interest": 3165.69,
      "balance": 493059.61
    }
  ]
}
```

### Scheme Comparison
```json
{
  "schemes": [...],
  "comparison_categories": [
    {
      "category": "Loan Amount",
      "values": [
        {
          "scheme_id": 1,
          "scheme_name": "PM MUDRA",
          "min_loan": "₹0",
          "max_loan": "₹10,00,000",
          "advantage": "High limit"
        }
      ]
    }
  ]
}
```

---

## 🔧 Integration Checklist

- [ ] Install all dependencies
- [ ] Update database models with required fields
- [ ] Configure CORS origins
- [ ] Set up email/SMS notification service
- [ ] Create admin dashboard UI
- [ ] Add feature routes to main API file
- [ ] Test all endpoints with sample data
- [ ] Integrate with frontend components
- [ ] Deploy to staging environment
- [ ] Run load testing
- [ ] Deploy to production

---

## 🐛 Troubleshooting

### Issue: "Module not found" error
**Solution:** Ensure all service files are in the correct path and `__init__.py` files exist in service directories.

### Issue: Database connection errors
**Solution:** Check DATABASE_URL environment variable and ensure database is running.

### Issue: CORS errors
**Solution:** Update CORS_ORIGINS in config.py with your frontend URL.

### Issue: Empty responses
**Solution:** Ensure database has seed data for schemes and partners.

---

## 📚 Additional Resources

- **API Documentation:** See `FEATURES_DOCUMENTATION.md`
- **Database Schema:** See `database/schema.sql`
- **Environment Variables:** See `.env.example`

---

## 🚀 Deployment Steps

### Local Development
```bash
# Start backend
cd backend && uvicorn app.main:app --reload

# Start frontend (in another terminal)
cd frontend && npm run dev
```

### Production Deployment
```bash
# Build frontend
cd frontend && npm run build

# Start backend with gunicorn
cd backend && gunicorn -w 4 -k uvicorn.workers.UvicornWorker app.main:app
```

---

## 📞 Support

For feature requests or bug reports:
1. Check existing documentation
2. Review error messages carefully
3. Check API response codes
4. Consult service docstrings
5. Contact development team

---

**Last Updated:** September 16, 2024  
**API Version:** 1.0.0
