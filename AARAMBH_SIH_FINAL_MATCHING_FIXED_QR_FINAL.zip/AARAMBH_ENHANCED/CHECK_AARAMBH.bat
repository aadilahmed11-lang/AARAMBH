@echo off
setlocal
cd /d "%~dp0"
echo Checking AARAMBH...
call backend\venv\Scripts\python.exe -m compileall -q backend
if errorlevel 1 goto :fail
if exist frontend\node_modules\.bin\vite.cmd (
  cd frontend
  call npm.cmd run build
  if errorlevel 1 goto :fail
  cd ..
) else (
  echo Frontend dependencies are not installed yet. Run SETUP_AARAMBH.bat first.
)
echo.
echo AARAMBH checks completed.
pause
exit /b 0
:fail
echo.
echo AARAMBH check failed. Read the error above.
pause
exit /b 1
