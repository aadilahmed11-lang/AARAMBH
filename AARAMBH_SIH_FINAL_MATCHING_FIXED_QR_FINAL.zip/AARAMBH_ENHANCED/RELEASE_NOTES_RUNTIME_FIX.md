# AARAMBH Runtime Fix

Fixed the runtime/rendering issues reported in the Vite console:

- Added the missing `Connectivity` component used by the authenticated layout.
- Added the missing `Landing` component used before login.
- Removed the duplicate `one` key from the spoken-number map.
- Kept the one-question voice-entry flow and made inline voice start without opening the larger floating help panel.
- Backend requirements include `uvicorn[standard]`.

The source was checked for duplicate function declarations, critical missing component references, and backend Python compilation. A full frontend npm build was not possible in the packaging environment because npm registry access timed out.
