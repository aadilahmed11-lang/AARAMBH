# AARAMBH prototype audit and repair notes

## What was present in the supplied prototype

- Applicant, Channel Partner and Government/Admin role separation.
- Rule-based scheme recommendation with TF-IDF ranking.
- EMI calculator, documents/OCR, partner routing, applications, QR, notifications and analytics services.
- A basic education scheme seed existed, but it was generic and the applicant UI did not have a dedicated education dashboard.
- Several of the documented "20 features" referenced model fields that did not exist in the actual SQLAlchemy models, so those endpoints could fail at runtime.

## Repairs in this version

### Business / Education separation
- Added a dedicated **Business Dashboard** for income-generating schemes.
- Added a dedicated **Education Dashboard** for course, institution, course-fee and study-location details.
- Applicant navigation now exposes both dashboards directly.
- Recommendation API now accepts `scheme_type` and filters the catalogue before ranking.

### Education catalogue
The seed now includes an Educational Loan Scheme plus education-focused discovery/support cards. The Educational Loan Scheme uses the current NSFDC FAQ values used for this prototype: up to ₹40 lakh or 90% of course fee (whichever is lower), 6.5% beneficiary rate, and a long repayment period with a course-related moratorium. The UI labels the catalogue as a prototype and retains the official source URL for verification.

### Business catalogue
The seed now represents the major business products described in the problem statement: Micro Finance, Aajeevika Micro-Finance, Term Loan and Udyam Nidhi, with project/loan ranges, interest, tenure, moratorium and coverage fields.

### Partner routing
- Added partner support for business/education scheme types.
- Added fund-utilization, NPA, overdue and rating fields.
- Routing excludes unavailable partners and partners failing the prototype's no-overdue / utilization gate.
- Matching considers distance, capacity, quality/rating and utilization.

### Backend runtime repairs
- Added missing database fields used by readiness/timeline services.
- Reworked readiness, eligibility explanation, match-card and analytics services to use the actual project models instead of nonexistent fields.
- Added an idempotent `backend/migrate.py` for an already-created MySQL `aarambh` database.
- Application creation validates scheme loan limits and attempts scheme-type-aware partner assignment.
- Status updates record document-review / partner-review / decision timestamps.
- Admin feature analytics endpoints are protected by the admin role.

## Important limitation

This environment could not complete `npm install` because outbound package downloads were unavailable, and it does not have the project's Python dependencies installed. Therefore a full browser build and live MySQL integration test could not be executed here. The backend Python files were syntax-checked with `compileall`.

Run the commands in `README.md` on the target Windows machine after configuring `backend/.env`.
