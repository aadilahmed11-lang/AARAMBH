# AARAMBH Final Workflow Update

This release changes the applicant journey to keep the full 11-step flow without a separate Compare step:

1. Choose path
2. Your details (one question at a time)
3. Business / Education details
4. Business idea / Education purpose
5. AI scheme match
6. Select scheme
7. Finance
8. Documents
9. 50 km partner
10. Submit
11. Done

## Applicant details
- Social category options include SC, ST, BC, OBC, BCM, EWS, General/Other and Prefer not to say.
- Separate PwD/disability questions include disability type and certificate percentage.
- Age, gender, family income, employment, marital status, residence, minority status, mobile number, state, district, city, identity/caste/income certificate availability and existing-loan status are collected.
- Text questions have a visible Speak your answer button and a Next button.
- Answers are saved as the user progresses.

## Scheme matching
The ranking endpoint returns a score, rank, eligibility state, matching factors and gaps using the applicant profile and scheme targeting/rules.

## Documents and application records
A Draft application record is created before document upload. Uploaded documents are attached to that application and can be verified by the assigned channel partner.

## Partner routing
After a scheme is selected, the app attempts to obtain browser location and displays eligible partners within 50 km with scheme interest rate and routing details. The final submission endpoint validates that the selected partner is still eligible and within the configured radius.

## Application tracking and QR
After final submission, AARAMBH generates an application ID, human-readable reference number and QR code. The QR opens a limited tracking page showing status, scheme and document verification states. Authorized partner/admin screens can view the fuller application record.

## Local development
- SQLite is the default database.
- Run `SETUP_AARAMBH.bat` for first-time setup, or install backend/frontend dependencies manually.
- Frontend: `npm.cmd run dev`
- Backend: `python -m uvicorn app.main:app --reload`
