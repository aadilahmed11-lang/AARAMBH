# AARAMBH — SIH Prototype (Enhanced)

AARAMBH is a government-finance scheme discovery and guided application prototype for SC beneficiaries. It now combines Business and Education applicant journeys with explainable scheme matching, neutral comparison, financial planning, document readiness, 50 km channel-partner routing, application tracking, multilingual UI foundations and offline-first PWA behavior.

## What is included in this SIH-enhanced build

### 1. Beneficiary journeys
- Separate Business Dashboard and Education Dashboard.
- Guided flow connects profile → scheme match → comparison → finance → documents → partner → application.
- Education flow collects course, institution, fee, location and duration.
- Business flow collects business type, stage, occupation and requested loan amount.

### 2. Explainable scheme matching
- Deterministic eligibility rules are evaluated before ranking.
- Top 5 matches are shown with a score and plain-language reasons.
- The UI explicitly treats the ranking as a support signal, not a guarantee.
- The comparison screen is neutral: it displays the configured terms without declaring a winner.

### 3. Scheme comparison
Compare up to three schemes side-by-side on:
- Loan range
- Interest rate
- Tenure
- Moratorium
- Coverage
- Benefit type
- Required documents
- Verification status

### 4. Financial planning
- Offline-capable EMI calculation.
- Monthly EMI, total repayment, total interest and moratorium display.
- The app clearly labels figures as estimates rather than sanction quotes.

### 5. Document readiness
- Application-specific required-document checklist.
- Upload and OCR workflow when online.
- Offline document metadata/blob storage for later synchronization.
- OCR is assistive and must be reviewed before submission.

### 6. 50 km partner routing
- Applicant browser location is requested with permission.
- Eligible active partners are filtered to a maximum 50 km radius.
- Scheme support and availability/capacity are considered.
- Prototype NPA/overdue gates are configurable and are NOT official government thresholds.
- Partner card shows distance, type, address, phone, capacity, rating, fund utilization, verification status and selected scheme interest rate.
- Directions use a Google Maps directions URL when connectivity is available.
- Cached partner coordinates can be used for distance calculation while offline.

### 7. Application tracking
- Applications have a reference number and current status.
- Applicant can open a timeline of status-history events.
- Application readiness shows profile, eligibility, document and financial/course completion components.
- Pending items are shown as recommended actions.

### 8. Offline-first PWA
The frontend includes a service worker, web manifest and IndexedDB storage.

Offline-capable prototype functions include:
- Opening the cached app shell
- Viewing cached scheme data
- Viewing cached partner data
- Business/Education scheme matching using cached rules/data
- EMI calculations
- Saving application submissions to a local queue
- Saving offline document blobs/metadata
- Calculating cached partner distance within 50 km

When connectivity returns, queued applications are synchronized through `/api/offline/sync` and a fresh data snapshot is cached.

The UI shows Online/Offline state and pending synchronization count. Cached government/partner data is displayed with its freshness/verification context; production should always refresh from an authoritative source.

### 9. Multilingual foundation
- English
- हिन्दी
- தமிழ்

Language preference is retained locally and the main navigation/common actions are translated. The same translation pattern can be extended to every field label and validation message during production localization.

### 10. Data governance
Government/Admin has scheme and partner governance screens to record:
- Data source
- Verification status
- Verification date
- Reviewer
- Next review date

The prototype intentionally does not label seeded partner records as officially verified. Replace demo partner data with a current authorized directory before production deployment.

## Demo accounts

- Applicant: `user@aarambh.local` / `user123`
- Partner: `partner@aarambh.local` / `partner123`
- Government/Admin: `admin@aarambh.local` / `admin123`

## Backend — Windows PowerShell

```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Create `backend/.env` from `.env.example`:

```env
DATABASE_URL=mysql+pymysql://root:YOUR_MYSQL_PASSWORD@127.0.0.1:3306/aarambh
JWT_SECRET=change-this-for-local-development
ACCESS_TOKEN_MINUTES=1440
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
UPLOAD_DIR=uploads
```

Create the database in MySQL Workbench if needed:

```sql
CREATE DATABASE aarambh;
```

For an existing AARAMBH database, run the idempotent migration before seeding:

```powershell
python migrate.py
python seed.py
```

Start the backend:

```powershell
python -m uvicorn app.main:app --reload
```

API docs: `http://127.0.0.1:8000/docs`

### If PowerShell says `No module named uvicorn`

Your virtual environment is active but dependencies are missing. Run:

```powershell
python -m pip install -r requirements.txt
```

Then:

```powershell
python -m uvicorn app.main:app --reload
```

## Frontend — Windows PowerShell

Open a second terminal:

```powershell
cd frontend
npm.cmd install
npm.cmd run dev
```

Then open the local Vite URL, normally `http://localhost:5173`.

If PowerShell blocks `npm.ps1`, use `npm.cmd` exactly as above.

## Offline/PWA notes

For the service worker and geolocation/PWA features to behave like a production PWA, serve the built frontend over HTTPS. `localhost` is also treated as a secure context by modern browsers for development. The backend remains the authoritative database; IndexedDB is a local cache/queue, not a replacement for MySQL.

A production offline deployment should add conflict resolution, authenticated background sync, encrypted local storage where required, current authorized partner feeds and a formal retention/privacy policy.

## Important prototype boundaries

- Aadhaar is NOT authenticated against UIDAI. Any Aadhaar-shaped demo flow must remain clearly labelled as a prototype.
- Scheme terms and eligibility can change. The app provides source links and governance fields but does not guarantee live government data.
- Seeded partner locations are demo records. They are not a live nationwide bank/channel-partner directory.
- Interest rate shown on a partner card is the selected scheme's configured rate, not a promise that the partner will sanction at that rate.
- Prototype NPA/overdue routing gates are configurable demo logic, not official NSFDC thresholds.
- Google Maps directions require connectivity unless the device has its own offline map capability.
- EMI values are estimates and should not be presented as sanction quotes.

## Suggested SIH demonstration path

1. Start on Business Dashboard.
2. Run the guided journey and show the Top 5 explainable scheme matches.
3. Compare two or three schemes.
4. Show EMI and moratorium.
5. Show required-document checklist.
6. Allow location and show eligible partners within 50 km with interest rate and directions.
7. Select a partner and submit/queue an application.
8. Open My Applications and show readiness + timeline.
9. Switch the browser offline and demonstrate cached schemes/partners, EMI and queued submission.
10. Reconnect and show synchronization.
11. Log in as Admin and demonstrate scheme/partner verification and analytics.

## Verification status

Backend Python modules were syntax-checked with `py_compile`. A full frontend dependency installation/build could not be completed in the packaging environment because package installation was unavailable/timed out; run `npm.cmd install` and `npm.cmd run build` locally before the final SIH presentation.

## AARAMBH Final Accessibility + Beginner Update

This package adds a beginner-friendly Windows setup path and a voice-first applicant experience.

### Voice-first multilingual support
- English (`en-IN`)
- Tamil (`ta-IN`)
- Hindi (`hi-IN`)
- Browser speech recognition using the Web Speech API
- Read-aloud using browser speech synthesis
- Voice commands can open Business, Education, Scheme, Documents, Partner and Application areas
- Guided Journey accepts spoken business/education information and can populate supported fields
- No cloud speech API key is required for the prototype

### Reliability improvements
- React error recovery screen instead of an unexplained blank page
- Dashboard loading, empty and offline states
- Mobile navigation drawer
- Retry/sync controls
- Offline cached data remains available where supported

### Beginner database mode
- SQLite is now the default database.
- First backend startup creates the database and seeds the demo catalogue automatically.
- MySQL remains supported through `DATABASE_URL`.
- If MySQL is configured but unavailable, SQLite fallback is enabled by default for local demonstration.

### Windows quick start
Double-click `SETUP_AARAMBH.bat` for first-time setup, then use `START_AARAMBH.bat` on later runs.

Demo credentials:
- Applicant: `user@aarambh.local` / `user123`
- Partner: `partner@aarambh.local` / `partner123`
- Admin: `admin@aarambh.local` / `admin123`

Partner and scheme records in the demo seed are prototype records. They should be replaced or synchronized with current authoritative data before production deployment.

## Guided journey update
- Applicant journey now uses 11 steps for both Business and Education paths.
- User details are collected one question at a time with option buttons where practical.
- Text questions support typing/Enter and the global voice assistant can place spoken answers into the current question.
- Voice help now gives spoken responses for common navigation/help commands and reads the next question after a voice answer.
- Fixed the React effect cleanup issue that caused `destroy is not a function` on dashboard rendering.
- SQLite is configured as the default local development database in `backend/.env`.


## Final UX and matching update
- Non-blocking collapsed voice helper with an inline **Speak your answer** button on every one-question profile screen.
- Voice answers advance automatically and the next question is read aloud.
- Applicant profile now captures age, gender, social category, disability status/type/percentage, marital status, urban/rural residence, minority status, employment status, location and document-readiness fields.
- Scheme ranking is deterministic and explainable: category, income, disability, age, state, purpose keywords, amount and configured eligibility rules contribute to the match score.
- Added additional government-scheme discovery records sourced from the official myScheme catalogue (including PM-DAKSH, PMEGP, PM SVANidhi and Khelo India inclusiveness support). State-specific eligibility must still be verified on the official scheme page.
- Existing SQLite databases are upgraded automatically with the new profile/scheme fields.
